@echo off
setlocal
powershell.exe -NoLogo -NoProfile -STA -ExecutionPolicy Bypass -File "%~dp0merge-desktop.ps1"
set "MERGE_STATUS=%ERRORLEVEL%"
pause
exit /b %MERGE_STATUS%
